from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import math

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Step 2: Create the Database Models
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    subjects = db.relationship('Subject', backref='student', lazy=True)

    def __repr__(self):
        return f'<Student {self.name}>'

class Subject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
    scores = db.relationship('Score', backref='subject', lazy=True)

    def __repr__(self):
        return f'<Subject {self.name}>'

class Score(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    score = db.Column(db.Float, nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey('subject.id'), nullable=False)

    def __repr__(self):
        return f'<Score {self.score}>'

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    score_range = db.Column(db.String(10), nullable=False)
    grade = db.Column(db.String(2), nullable=False)
    points = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return f'<Grade {self.grade}>'

def calculate_cgpa(student_id):
    student = Student.query.get(student_id)
    total_points = 0
    total_subjects = 0

    for subject in student.subjects:
        for score in subject.scores:
            grade = Grade.query.filter(Grade.score_range.contains(score.score)).first()
            if grade:
                total_points += grade.points
                total_subjects += 1

    return total_points / total_subjects if total_subjects > 0 else 0.0

# Step 3: Create Routes
@app.route('/')
def index():
    students = Student.query.all()
    return render_template('index.html', students=students)

@app.route('/student/<int:id>')
def student_detail(id):
    student = Student.query.get_or_404(id)
    cgpa = calculate_cgpa(id)
    return render_template('student_detail.html', student=student, cgpa=cgpa)

@app.route('/add_student', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        new_student = Student(name=name, age=age)
        try:
            db.session.add(new_student)
            db.session.commit()
            return redirect('/')
        except:
            return "There was an issue adding the student"
    else:
        return render_template('add_student.html')

@app.route('/add_subject/<int:student_id>', methods=['GET', 'POST'])
def add_subject(student_id):
    student = Student.query.get_or_404(student_id)
    if request.method == 'POST':
        name = request.form['name']
        new_subject = Subject(name=name, student_id=student_id)
        try:
            db.session.add(new_subject)
            db.session.commit()
            return redirect(url_for('student_detail', id=student_id))
        except:
            return "There was an issue adding the subject"
    else:
        return render_template('add_subject.html', student=student)

@app.route('/add_score/<int:subject_id>', methods=['GET', 'POST'])
def add_score(subject_id):
    subject = Subject.query.get_or_404(subject_id)
    if request.method == 'POST':
        score_value = request.form['score']
        new_score = Score(score=score_value, subject_id=subject_id)
        try:
            db.session.add(new_score)
            db.session.commit()
            return redirect(url_for('student_detail', id=subject.student_id))
        except:
            return "There was an issue adding the score"
    else:
        return render_template('add_score.html', subject=subject)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
